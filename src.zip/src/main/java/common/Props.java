package main.java.common;

public class Props {
	static String url1 = PropertyLoader.getInstance().getProperty("url1");
	static String url2 = PropertyLoader.getInstance().getProperty("url2");
	static String url3 = PropertyLoader.getInstance().getProperty("url3");
	static String url4 = PropertyLoader.getInstance().getProperty("url4");

}
